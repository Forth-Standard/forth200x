/**
 * This takes the email address as a set of domains, in reverse
 * order, with the punctioantion missing, and the user name as
 * the final argument.  It will then write the corrected email
 * address to the document.
 * <p/>
 * Example: <code>email("uk","org","bcs","pjk")</code> will produce
 * the email address <code>pjk@bcs.org.uk</code>.
 */
function email() {
    var last = arguments.length - 1;
    var str = arguments[0];
    for (var n = 1; n < last; n++) {
        str = arguments[n] + "&#46;" + str;
    }
    document.write(arguments[last] + "&#64;" + str);
}